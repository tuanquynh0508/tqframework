<h2>Test widget</h2>
<?php echo $date; ?>