<div class="wrapper col4">
  <div id="container" class="clear">
    <!-- ####################################################################################################### -->
    <div id="shout" class="clear">
      <div class="fl_left">
        <h2>Need A Professional Photographer ?</h2>
        <p>Why not try our services today, you won't regret your choice !</p>
      </div>
      <p class="fl_right"><a href="#contact">Contact Us Today</a></p>
    </div>
    <!-- ####################################################################################################### -->
    <h1>Our Portfolio</h1>
    <div id="portfolio">
      <ul>
        <li>
          <div class="imgholder"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/piecemaker/960x360.gif" alt="" /></div>
          <p class="title">Project Name Here</p>
          <p class="projectdescription">Duivelit vitanterdum metus laorem non arcu justo tor a elerisuspenas inte. Tempormi at auctortor dui senean tur intesque nam a met ut. Urnadolor feugiat nonummy alique doloreet malesuada sed vestie ipsum in praesent. Nibhat aenean intesque et at eger leo vestibulum tellus tor sus. Inut morbi leo lacus orci laoreet nam et temper mauris sodalesuada.</p>
          <p class="readmore"><a href="#"><strong>View The Full Project &raquo;</strong></a></p>
        </li>
        <li>
          <div class="imgholder"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/piecemaker/960x360.gif" alt="" /></div>
          <p class="title">Project Name Here</p>
          <p class="projectdescription">Duivelit vitanterdum metus laorem non arcu justo tor a elerisuspenas inte. Tempormi at auctortor dui senean tur intesque nam a met ut. Urnadolor feugiat nonummy alique doloreet malesuada sed vestie ipsum in praesent. Nibhat aenean intesque et at eger leo vestibulum tellus tor sus. Inut morbi leo lacus orci laoreet nam et temper mauris sodalesuada.</p>
          <p class="readmore"><a href="#"><strong>View The Full Project &raquo;</strong></a></p>
        </li>
        <li class="last">
          <div class="imgholder"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/piecemaker/960x360.gif" alt="" /></div>
          <p class="title">Project Name Here</p>
          <p class="projectdescription">Duivelit vitanterdum metus laorem non arcu justo tor a elerisuspenas inte. Tempormi at auctortor dui senean tur intesque nam a met ut. Urnadolor feugiat nonummy alique doloreet malesuada sed vestie ipsum in praesent. Nibhat aenean intesque et at eger leo vestibulum tellus tor sus. Inut morbi leo lacus orci laoreet nam et temper mauris sodalesuada.</p>
          <p class="readmore"><a href="#"><strong>View The Full Project &raquo;</strong></a></p>
        </li>
      </ul>
    </div>
    <!-- ####################################################################################################### -->
    <div class="pagination">
      <ul>
        <li class="prev"><a href="#">&laquo; Previous</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li class="splitter">&hellip;</li>
        <li><a href="#">6</a></li>
        <li class="current">7</li>
        <li><a href="#">8</a></li>
        <li><a href="#">9</a></li>
        <li class="splitter">&hellip;</li>
        <li><a href="#">14</a></li>
        <li><a href="#">15</a></li>
        <li class="next"><a href="#">Next &raquo;</a></li>
      </ul>
    </div>
    <!-- ####################################################################################################### -->
    <div class="clear"></div>
  </div>
</div>