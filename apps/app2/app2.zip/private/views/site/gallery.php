<div class="wrapper col4">
  <div id="container" class="clear">
    <!-- ####################################################################################################### -->
    <div id="shout" class="clear">
      <div class="fl_left">
        <h2>Need A Professional Photographer ?</h2>
        <p>Why not try our services today, you won't regret your choice !</p>
      </div>
      <p class="fl_right"><a href="#contact">Contact Us Today</a></p>
    </div>
    <!-- ####################################################################################################### -->
    <h1>Gallery Category Name Here</h1>
    <div class="gallery clear">
      <ul>
        <li class="first"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" alt="" /></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 1"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 2"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 3"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 4"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li class="first"><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 5"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 6"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 7"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 8"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 9"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li class="first"><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 10"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 11"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 12"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 13"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
        <li><a href="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/572x330.gif" rel="prettyPhoto[gallery1]" title="Image 14"><img src="<?php echo $TQApp->getWebpath(); ?>images/demo/gallery/174x150.gif" alt="" /></a></li>
      </ul>
    </div>
    <!-- ####################################################################################################### -->
    <div class="pagination">
      <ul>
        <li class="prev"><a href="#">&laquo; Previous</a></li>
        <li><a href="#">1</a></li>
        <li><a href="#">2</a></li>
        <li class="splitter">&hellip;</li>
        <li><a href="#">6</a></li>
        <li class="current">7</li>
        <li><a href="#">8</a></li>
        <li><a href="#">9</a></li>
        <li class="splitter">&hellip;</li>
        <li><a href="#">14</a></li>
        <li><a href="#">15</a></li>
        <li class="next"><a href="#">Next &raquo;</a></li>
      </ul>
    </div>
    <!-- ####################################################################################################### -->
    <div class="clear"></div>
  </div>
</div>